
typedef int buffer_item;
#define BUFFER_SIZE 5